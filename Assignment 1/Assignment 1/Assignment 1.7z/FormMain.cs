﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_1
{
    public partial class FormMain : Form
    {
        private Fish[] fishType;
        private int fishNum = Fish.GetName.Length;

        private List<Fleet> boatNum = new List<Fleet>();
        private Fleet currentBoat;

        private int boatCount = 0;
        private int boatIncrement = 1;
        private decimal[] totalQuota = new decimal[9];
        private decimal[] totalFactorQuota = new decimal[9];
        private int fleetLoopCount = 9;
        private string weightOutput = "kg";

        public FormMain()
        {
            InitializeComponent();
            FishCreator();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
        }

        private void FishCreator()
        {
            fishType = new Fish[fishNum];
            for (int i = 0; i < fishNum; i++)
            {
                fishType[i] = new Fish(Fish.GetName[i], Fish.GetFactor[i], Fish.GetQuota[i]);
                speciesComboBox1.Items.Add(Fish.GetName[i]);
                speciesComboBox2.Items.Add(Fish.GetName[i]);
                speciesComboBox3.Items.Add(Fish.GetName[i]);
                speciesComboBox4.Items.Add(Fish.GetName[i]);
            }
            ShowCurrentFish(fishType);
        }

        private void ShowCurrentFish(Fish[] fishType)
        {
            fishOutputBox.Text = string.Empty;
            fishOutputBox.AppendText("Name" + "\t\t" + "Factor" + "\t\t" + "Quota" + Environment.NewLine);
            for (int i = 0; i < fishNum; i++)
            {
                switch (Fish.GetName[i].Length)
                {
                    case int n when (n > 7):
                        fishOutputBox.Text += Fish.GetName[i];
                        fishOutputBox.AppendText("\t");
                        fishOutputBox.Text += Fish.GetFactor[i];
                        fishOutputBox.AppendText("\t\t");
                        fishOutputBox.Text += Fish.GetQuota[i];
                        fishOutputBox.Text += Environment.NewLine;
                        break;
                    default:
                        fishOutputBox.Text += Fish.GetName[i];
                        fishOutputBox.AppendText("\t\t");
                        fishOutputBox.Text += Fish.GetFactor[i];
                        fishOutputBox.AppendText("\t\t");
                        fishOutputBox.Text += Fish.GetQuota[i];
                        fishOutputBox.Text += Environment.NewLine;
                        break;
                }
            }
        }

        private void SubmitShipNameButton_MouseClick(object sender, MouseEventArgs e)
        {
            ShipCreator();
            if(currentBoat != null)
            {
                QuotaMemory();
            }
            
        }

        private void ShipCreator()
        {
            string tempName = nameTextBox.Text;
            string tempLicense = licenseTextBox.Text;
            decimal tempMaxLoad = Decimal.Parse(maxLoadTextBox.Text);

            string[] tempFishSpecies = new string [fleetLoopCount];
            if (Array.IndexOf(Fish.GetName, speciesComboBox1.Text) == -1) {}
            else { tempFishSpecies[Array.IndexOf(Fish.GetName, speciesComboBox1.Text)] = speciesComboBox1.Text; }
            if (Array.IndexOf(Fish.GetName, speciesComboBox2.Text) == -1) {}
            else { tempFishSpecies[Array.IndexOf(Fish.GetName, speciesComboBox2.Text)] = speciesComboBox2.Text; }
            if (Array.IndexOf(Fish.GetName, speciesComboBox3.Text) == -1) {}
            else { tempFishSpecies[Array.IndexOf(Fish.GetName, speciesComboBox3.Text)] = speciesComboBox3.Text; }
            if (Array.IndexOf(Fish.GetName, speciesComboBox4.Text) == -1) {}
            else { tempFishSpecies[Array.IndexOf(Fish.GetName, speciesComboBox4.Text)] = speciesComboBox4.Text; }

            decimal[] tempQuotaArray = new decimal[fleetLoopCount];
            if (Array.IndexOf(Fish.GetName, speciesComboBox1.Text) == -1) {}
            else { tempQuotaArray[Array.IndexOf(Fish.GetName, speciesComboBox1.Text)] += Decimal.Parse(quotaFilledTextBox1.Text); }
            if (Array.IndexOf(Fish.GetName, speciesComboBox2.Text) == -1) {}
            else { tempQuotaArray[Array.IndexOf(Fish.GetName, speciesComboBox2.Text)] += Decimal.Parse(quotaFilledTextBox2.Text); }
            if (Array.IndexOf(Fish.GetName, speciesComboBox3.Text) == -1) {}
            else { tempQuotaArray[Array.IndexOf(Fish.GetName, speciesComboBox3.Text)] += Decimal.Parse(quotaFilledTextBox3.Text); }
            if (Array.IndexOf(Fish.GetName, speciesComboBox4.Text) == -1) {}
            else { tempQuotaArray[Array.IndexOf(Fish.GetName, speciesComboBox4.Text)] += Decimal.Parse(quotaFilledTextBox4.Text); }

            decimal tempHaul = 0;
            if (quotaFilledTextBox1.Text == "") {}
            else { tempHaul += Decimal.Parse(quotaFilledTextBox1.Text); }
            if (quotaFilledTextBox2.Text == "") {}
            else { tempHaul += Decimal.Parse(quotaFilledTextBox2.Text); }
            if (quotaFilledTextBox3.Text == "") {}
            else { tempHaul += Decimal.Parse(quotaFilledTextBox3.Text); }
            if (quotaFilledTextBox4.Text == "") {}
            else { tempHaul += Decimal.Parse(quotaFilledTextBox4.Text); }

            if(tempHaul > tempMaxLoad)
            {
                MessageBox.Show("You have a greater load than capacity, please verify.");
                tempHaul = 0;
                tempMaxLoad = 0;
                return;
            }

            decimal[] tempLiveWeight = new decimal[fleetLoopCount];

            if (quotaFilledTextBox1.Text == "") { }
            else { tempLiveWeight[Array.IndexOf(Fish.GetName, speciesComboBox1.Text)] = Fish.GetFactor[Array.IndexOf(Fish.GetName, speciesComboBox1.Text)] * Decimal.Parse(quotaFilledTextBox1.Text); }
            if (quotaFilledTextBox2.Text == "") { }
            else { tempLiveWeight[Array.IndexOf(Fish.GetName, speciesComboBox2.Text)] = Fish.GetFactor[Array.IndexOf(Fish.GetName, speciesComboBox2.Text)] * Decimal.Parse(quotaFilledTextBox2.Text); }
            if (quotaFilledTextBox3.Text == "") { }
            else { tempLiveWeight[Array.IndexOf(Fish.GetName, speciesComboBox3.Text)] = Fish.GetFactor[Array.IndexOf(Fish.GetName, speciesComboBox3.Text)] * Decimal.Parse(quotaFilledTextBox3.Text); }
            if (quotaFilledTextBox4.Text == "") { }
            else { tempLiveWeight[Array.IndexOf(Fish.GetName, speciesComboBox4.Text)] = Fish.GetFactor[Array.IndexOf(Fish.GetName, speciesComboBox4.Text)] * Decimal.Parse(quotaFilledTextBox4.Text); }

            boatNum.Add(new Fleet(tempName, tempLicense, tempMaxLoad, tempHaul, tempFishSpecies, tempQuotaArray, tempLiveWeight));
            boatSelectionComboBox.Items.Add(boatNum[boatCount].GetName);
            currentBoat = boatNum[boatCount];
            boatCount += boatIncrement;
        }

        private void QuotaMemory()
        {
            for (int i = 0; i < fleetLoopCount; i++)
            {
                totalQuota[i] += currentBoat.GetFilledQuota[i];
                totalFactorQuota[i] += currentBoat.GetLiveWeight[i];
            }
        }

        private void ShowCurrentBoat(Fleet currentBoat)
        {
            shipOutputBox.Text = string.Empty;
            shipOutputBox.Text += "Name: ";
            shipOutputBox.Text += currentBoat.GetName;
            shipOutputBox.Text += Environment.NewLine;
            shipOutputBox.AppendText("License: " + currentBoat.GetLicence + Environment.NewLine);
            shipOutputBox.AppendText("Maximum Capacity: " + currentBoat.GetMaximumLoad + weightOutput + Environment.NewLine);
            for (int i = 0; i < fleetLoopCount; i++)
            {
                if (currentBoat.GetFishSpecies[i] == null)
                {
                }
                else
                {
                    shipOutputBox.AppendText(currentBoat.GetFishSpecies[i] + " Fished: " + currentBoat.GetFilledQuota[i] + weightOutput + Environment.NewLine);
                    shipOutputBox.AppendText(currentBoat.GetFishSpecies[i] + " Live Weight: " + currentBoat.GetLiveWeight[i] + weightOutput + Environment.NewLine);
                }
            }
            shipOutputBox.AppendText("Ship Haul: " + currentBoat.GetShipHaul + weightOutput + Environment.NewLine);
            ShowCurrentQuota(currentBoat);
        }

        private void ShowCurrentQuota(Fleet currentBoat)
        {
            quotaOutputBox.Text = string.Empty;
            quotaOutputBox.AppendText("Name" + "\t\t" + "Fished" + "\t\t" + "Quota" + Environment.NewLine);
            for (int i = 0; i < fleetLoopCount; i++)
            {
                switch (Fish.GetName[i].Length)
                {
                    case int n when (n > 7):
                        quotaOutputBox.Text += Fish.GetName[i];
                        quotaOutputBox.AppendText("\t");
                        quotaOutputBox.AppendText(totalFactorQuota[i] + weightOutput);
                        quotaOutputBox.AppendText("\t\t");
                        quotaOutputBox.Text += Fish.GetQuota[i] + weightOutput + Environment.NewLine;
                        break;
                    default:
                        quotaOutputBox.Text += Fish.GetName[i];
                        quotaOutputBox.AppendText("\t\t");
                        quotaOutputBox.AppendText(totalFactorQuota[i] + weightOutput);
                        quotaOutputBox.AppendText("\t\t");
                        quotaOutputBox.Text += Fish.GetQuota[i] + weightOutput + Environment.NewLine;
                        break;
                }
            }
        }

        private decimal kgToTonnes(decimal tonnes)
        {
            return tonnes / 1000;
        }

        private void kgButton_Click(object sender, EventArgs e)
        {
            weightOutput = "kg";
            ShowCurrentBoat(currentBoat);
        }

        private void tonneButton_Click(object sender, EventArgs e)
        {
            weightOutput = "t";

            shipOutputBox.Text = string.Empty;
            shipOutputBox.Text += "Name: ";
            shipOutputBox.Text += currentBoat.GetName;
            shipOutputBox.Text += Environment.NewLine;
            shipOutputBox.AppendText("License: " + currentBoat.GetLicence + Environment.NewLine);
            shipOutputBox.AppendText("Maximum Capacity: " + kgToTonnes(currentBoat.GetMaximumLoad) + weightOutput + Environment.NewLine);
            for (int i = 0; i < fleetLoopCount; i++)
            {
                if (currentBoat.GetFishSpecies[i] == null)
                {
                }
                else
                {
                    shipOutputBox.AppendText(currentBoat.GetFishSpecies[i] + " Fished: " + kgToTonnes(currentBoat.GetFilledQuota[i]) + weightOutput + Environment.NewLine);
                    shipOutputBox.AppendText(currentBoat.GetFishSpecies[i] + " Live Weight: " + kgToTonnes(currentBoat.GetLiveWeight[i]) + weightOutput + Environment.NewLine);
                }
            }
            shipOutputBox.AppendText("Ship Haul: " + kgToTonnes(currentBoat.GetShipHaul) + weightOutput + Environment.NewLine);

            quotaOutputBox.Text = string.Empty;
            quotaOutputBox.AppendText("Name" + "\t\t" + "Fished" + "\t\t" + "Quota" + Environment.NewLine);
            for (int i = 0; i < fleetLoopCount; i++)
            {
                switch (Fish.GetName[i].Length)
                {
                    case int n when (n > 7):
                        quotaOutputBox.Text += Fish.GetName[i];
                        quotaOutputBox.AppendText("\t");
                        quotaOutputBox.AppendText(kgToTonnes(totalFactorQuota[i]) + weightOutput);
                        quotaOutputBox.AppendText("\t\t");
                        quotaOutputBox.Text += kgToTonnes(Fish.GetQuota[i]) + weightOutput + Environment.NewLine;
                        break;
                    default:
                        quotaOutputBox.Text += Fish.GetName[i];
                        quotaOutputBox.AppendText("\t\t");
                        quotaOutputBox.AppendText(kgToTonnes(totalFactorQuota[i]) + weightOutput);
                        quotaOutputBox.AppendText("\t\t");
                        quotaOutputBox.Text += kgToTonnes(Fish.GetQuota[i]) + weightOutput + Environment.NewLine;
                        break;
                }
            }
            weightOutput = "kg";
        }

        private void totalHaulTextBox_TextChanged(object sender, EventArgs e)
        {
            for(int i = 0; i < fleetLoopCount; i++)
            {
                totalHaulTextBox.AppendText(totalQuota[i].ToString());
            }
        }

        private void boatSelectionComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            currentBoat = boatNum[boatSelectionComboBox.SelectedIndex];
            ShowCurrentBoat(currentBoat);
        }

        private void speciesComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (speciesComboBox1.SelectedItem == speciesComboBox2.SelectedItem || speciesComboBox1.SelectedItem == speciesComboBox3.SelectedItem || speciesComboBox1.SelectedItem == speciesComboBox4.SelectedItem)
            {
                if (speciesComboBox1.SelectedIndex == -1)
                {
                    return;
                }
                MessageBox.Show("You cannot select the same species twice.");
                speciesComboBox1.SelectedIndex = -1;
            }
        }

        private void speciesComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (speciesComboBox2.SelectedItem == speciesComboBox1.SelectedItem || speciesComboBox2.SelectedItem == speciesComboBox3.SelectedItem || speciesComboBox2.SelectedItem == speciesComboBox4.SelectedItem)
            {
                if (speciesComboBox2.SelectedIndex == -1)
                {
                    return;
                }
                MessageBox.Show("You cannot select the same species twice.");
                speciesComboBox2.SelectedIndex = -1;
            }
        }

        private void speciesComboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (speciesComboBox3.SelectedItem == speciesComboBox1.SelectedItem || speciesComboBox3.SelectedItem == speciesComboBox2.SelectedItem || speciesComboBox3.SelectedItem == speciesComboBox4.SelectedItem)
            {
                if (speciesComboBox3.SelectedIndex == -1)
                {
                    return;
                }
                MessageBox.Show("You cannot select the same species twice.");
                speciesComboBox3.SelectedIndex = -1;
            }

        }

        private void speciesComboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (speciesComboBox4.SelectedItem == speciesComboBox1.SelectedItem || speciesComboBox1.SelectedItem == speciesComboBox2.SelectedItem || speciesComboBox1.SelectedItem == speciesComboBox3.SelectedItem)
            {
                if (speciesComboBox4.SelectedIndex == -1)
                {
                    return;
                }
                MessageBox.Show("You cannot select the same species twice.");
                speciesComboBox4.SelectedIndex = -1;
            }
        }
    }
}
