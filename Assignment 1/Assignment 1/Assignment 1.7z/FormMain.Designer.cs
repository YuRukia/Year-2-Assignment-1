﻿namespace Assignment_1
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.submitShipNameButton = new System.Windows.Forms.Button();
            this.shipOutputBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.fishOutputBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.licenseTextBox = new System.Windows.Forms.TextBox();
            this.maxLoadTextBox = new System.Windows.Forms.TextBox();
            this.speciesComboBox1 = new System.Windows.Forms.ComboBox();
            this.speciesComboBox2 = new System.Windows.Forms.ComboBox();
            this.speciesComboBox3 = new System.Windows.Forms.ComboBox();
            this.speciesComboBox4 = new System.Windows.Forms.ComboBox();
            this.quotaFilledTextBox1 = new System.Windows.Forms.TextBox();
            this.quotaFilledTextBox2 = new System.Windows.Forms.TextBox();
            this.quotaFilledTextBox3 = new System.Windows.Forms.TextBox();
            this.quotaFilledTextBox4 = new System.Windows.Forms.TextBox();
            this.boatSelectionComboBox = new System.Windows.Forms.ComboBox();
            this.quotaOutputBox = new System.Windows.Forms.TextBox();
            this.totalHaulTextBox = new System.Windows.Forms.TextBox();
            this.kgButton = new System.Windows.Forms.Button();
            this.tonneButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // submitShipNameButton
            // 
            this.submitShipNameButton.Location = new System.Drawing.Point(6, 87);
            this.submitShipNameButton.Name = "submitShipNameButton";
            this.submitShipNameButton.Size = new System.Drawing.Size(153, 48);
            this.submitShipNameButton.TabIndex = 1;
            this.submitShipNameButton.Text = "Submit";
            this.submitShipNameButton.UseVisualStyleBackColor = true;
            this.submitShipNameButton.MouseClick += new System.Windows.Forms.MouseEventHandler(this.SubmitShipNameButton_MouseClick);
            // 
            // shipOutputBox
            // 
            this.shipOutputBox.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.shipOutputBox.Location = new System.Drawing.Point(13, 174);
            this.shipOutputBox.Multiline = true;
            this.shipOutputBox.Name = "shipOutputBox";
            this.shipOutputBox.ReadOnly = true;
            this.shipOutputBox.Size = new System.Drawing.Size(273, 233);
            this.shipOutputBox.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 27;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 28;
            this.label2.Text = "License";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 29;
            this.label3.Text = "Max Load";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(198, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 30;
            this.label4.Text = "Species";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(308, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 13);
            this.label7.TabIndex = 33;
            this.label7.Text = "Quota Filled";
            // 
            // fishOutputBox
            // 
            this.fishOutputBox.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fishOutputBox.Location = new System.Drawing.Point(292, 175);
            this.fishOutputBox.Multiline = true;
            this.fishOutputBox.Name = "fishOutputBox";
            this.fishOutputBox.ReadOnly = true;
            this.fishOutputBox.Size = new System.Drawing.Size(249, 136);
            this.fishOutputBox.TabIndex = 38;
            this.fishOutputBox.TextChanged += new System.EventHandler(this.FormMain_Load);
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(59, 9);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(100, 20);
            this.nameTextBox.TabIndex = 39;
            // 
            // licenseTextBox
            // 
            this.licenseTextBox.Location = new System.Drawing.Point(59, 34);
            this.licenseTextBox.Name = "licenseTextBox";
            this.licenseTextBox.Size = new System.Drawing.Size(100, 20);
            this.licenseTextBox.TabIndex = 40;
            // 
            // maxLoadTextBox
            // 
            this.maxLoadTextBox.Location = new System.Drawing.Point(59, 60);
            this.maxLoadTextBox.Name = "maxLoadTextBox";
            this.maxLoadTextBox.Size = new System.Drawing.Size(100, 20);
            this.maxLoadTextBox.TabIndex = 42;
            // 
            // speciesComboBox1
            // 
            this.speciesComboBox1.FormattingEnabled = true;
            this.speciesComboBox1.Location = new System.Drawing.Point(169, 31);
            this.speciesComboBox1.MaxDropDownItems = 10;
            this.speciesComboBox1.Name = "speciesComboBox1";
            this.speciesComboBox1.Size = new System.Drawing.Size(121, 21);
            this.speciesComboBox1.TabIndex = 43;
            this.speciesComboBox1.SelectedIndexChanged += new System.EventHandler(this.speciesComboBox1_SelectedIndexChanged);
            // 
            // speciesComboBox2
            // 
            this.speciesComboBox2.FormattingEnabled = true;
            this.speciesComboBox2.Location = new System.Drawing.Point(169, 59);
            this.speciesComboBox2.MaxDropDownItems = 10;
            this.speciesComboBox2.Name = "speciesComboBox2";
            this.speciesComboBox2.Size = new System.Drawing.Size(121, 21);
            this.speciesComboBox2.TabIndex = 44;
            this.speciesComboBox2.SelectedIndexChanged += new System.EventHandler(this.speciesComboBox2_SelectedIndexChanged);
            // 
            // speciesComboBox3
            // 
            this.speciesComboBox3.FormattingEnabled = true;
            this.speciesComboBox3.Location = new System.Drawing.Point(169, 87);
            this.speciesComboBox3.MaxDropDownItems = 10;
            this.speciesComboBox3.Name = "speciesComboBox3";
            this.speciesComboBox3.Size = new System.Drawing.Size(121, 21);
            this.speciesComboBox3.TabIndex = 45;
            this.speciesComboBox3.SelectedIndexChanged += new System.EventHandler(this.speciesComboBox3_SelectedIndexChanged);
            // 
            // speciesComboBox4
            // 
            this.speciesComboBox4.FormattingEnabled = true;
            this.speciesComboBox4.Location = new System.Drawing.Point(169, 115);
            this.speciesComboBox4.MaxDropDownItems = 11;
            this.speciesComboBox4.Name = "speciesComboBox4";
            this.speciesComboBox4.Size = new System.Drawing.Size(121, 21);
            this.speciesComboBox4.TabIndex = 46;
            this.speciesComboBox4.SelectedIndexChanged += new System.EventHandler(this.speciesComboBox4_SelectedIndexChanged);
            // 
            // quotaFilledTextBox1
            // 
            this.quotaFilledTextBox1.Location = new System.Drawing.Point(296, 31);
            this.quotaFilledTextBox1.Name = "quotaFilledTextBox1";
            this.quotaFilledTextBox1.Size = new System.Drawing.Size(100, 20);
            this.quotaFilledTextBox1.TabIndex = 47;
            // 
            // quotaFilledTextBox2
            // 
            this.quotaFilledTextBox2.Location = new System.Drawing.Point(296, 61);
            this.quotaFilledTextBox2.Name = "quotaFilledTextBox2";
            this.quotaFilledTextBox2.Size = new System.Drawing.Size(100, 20);
            this.quotaFilledTextBox2.TabIndex = 48;
            // 
            // quotaFilledTextBox3
            // 
            this.quotaFilledTextBox3.Location = new System.Drawing.Point(296, 87);
            this.quotaFilledTextBox3.Name = "quotaFilledTextBox3";
            this.quotaFilledTextBox3.Size = new System.Drawing.Size(100, 20);
            this.quotaFilledTextBox3.TabIndex = 49;
            // 
            // quotaFilledTextBox4
            // 
            this.quotaFilledTextBox4.Location = new System.Drawing.Point(296, 115);
            this.quotaFilledTextBox4.Name = "quotaFilledTextBox4";
            this.quotaFilledTextBox4.Size = new System.Drawing.Size(100, 20);
            this.quotaFilledTextBox4.TabIndex = 50;
            // 
            // boatSelectionComboBox
            // 
            this.boatSelectionComboBox.FormattingEnabled = true;
            this.boatSelectionComboBox.Location = new System.Drawing.Point(13, 142);
            this.boatSelectionComboBox.Name = "boatSelectionComboBox";
            this.boatSelectionComboBox.Size = new System.Drawing.Size(146, 21);
            this.boatSelectionComboBox.TabIndex = 51;
            this.boatSelectionComboBox.SelectedIndexChanged += new System.EventHandler(this.boatSelectionComboBox_SelectedIndexChanged);
            // 
            // quotaOutputBox
            // 
            this.quotaOutputBox.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.quotaOutputBox.Location = new System.Drawing.Point(293, 318);
            this.quotaOutputBox.Multiline = true;
            this.quotaOutputBox.Name = "quotaOutputBox";
            this.quotaOutputBox.ReadOnly = true;
            this.quotaOutputBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.quotaOutputBox.Size = new System.Drawing.Size(246, 139);
            this.quotaOutputBox.TabIndex = 52;
            // 
            // totalHaulTextBox
            // 
            this.totalHaulTextBox.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.totalHaulTextBox.Location = new System.Drawing.Point(13, 414);
            this.totalHaulTextBox.Multiline = true;
            this.totalHaulTextBox.Name = "totalHaulTextBox";
            this.totalHaulTextBox.ReadOnly = true;
            this.totalHaulTextBox.Size = new System.Drawing.Size(273, 43);
            this.totalHaulTextBox.TabIndex = 53;
            this.totalHaulTextBox.TextChanged += new System.EventHandler(this.totalHaulTextBox_TextChanged);
            // 
            // kgButton
            // 
            this.kgButton.Location = new System.Drawing.Point(169, 140);
            this.kgButton.Name = "kgButton";
            this.kgButton.Size = new System.Drawing.Size(117, 23);
            this.kgButton.TabIndex = 54;
            this.kgButton.Text = "KG";
            this.kgButton.UseVisualStyleBackColor = true;
            this.kgButton.Click += new System.EventHandler(this.kgButton_Click);
            // 
            // tonneButton
            // 
            this.tonneButton.Location = new System.Drawing.Point(292, 141);
            this.tonneButton.Name = "tonneButton";
            this.tonneButton.Size = new System.Drawing.Size(103, 23);
            this.tonneButton.TabIndex = 55;
            this.tonneButton.Text = "Tonne";
            this.tonneButton.UseVisualStyleBackColor = true;
            this.tonneButton.Click += new System.EventHandler(this.tonneButton_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 469);
            this.Controls.Add(this.tonneButton);
            this.Controls.Add(this.kgButton);
            this.Controls.Add(this.totalHaulTextBox);
            this.Controls.Add(this.quotaOutputBox);
            this.Controls.Add(this.boatSelectionComboBox);
            this.Controls.Add(this.quotaFilledTextBox4);
            this.Controls.Add(this.quotaFilledTextBox3);
            this.Controls.Add(this.quotaFilledTextBox2);
            this.Controls.Add(this.quotaFilledTextBox1);
            this.Controls.Add(this.speciesComboBox4);
            this.Controls.Add(this.speciesComboBox3);
            this.Controls.Add(this.speciesComboBox2);
            this.Controls.Add(this.speciesComboBox1);
            this.Controls.Add(this.maxLoadTextBox);
            this.Controls.Add(this.licenseTextBox);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.fishOutputBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.shipOutputBox);
            this.Controls.Add(this.submitShipNameButton);
            this.Name = "FormMain";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button submitShipNameButton;
        private System.Windows.Forms.TextBox shipOutputBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox fishOutputBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox licenseTextBox;
        private System.Windows.Forms.TextBox maxLoadTextBox;
        private System.Windows.Forms.ComboBox speciesComboBox1;
        private System.Windows.Forms.ComboBox speciesComboBox2;
        private System.Windows.Forms.ComboBox speciesComboBox3;
        private System.Windows.Forms.ComboBox speciesComboBox4;
        private System.Windows.Forms.TextBox quotaFilledTextBox1;
        private System.Windows.Forms.TextBox quotaFilledTextBox2;
        private System.Windows.Forms.TextBox quotaFilledTextBox3;
        private System.Windows.Forms.TextBox quotaFilledTextBox4;
        private System.Windows.Forms.ComboBox boatSelectionComboBox;
        private System.Windows.Forms.TextBox quotaOutputBox;
        private System.Windows.Forms.TextBox totalHaulTextBox;
        private System.Windows.Forms.Button kgButton;
        private System.Windows.Forms.Button tonneButton;
    }
}

