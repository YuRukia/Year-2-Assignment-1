﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_1
{
    class Fleet
    {

        private string Name;
        private string LicenceNumber;
        private decimal MaximumLoad;
        private decimal ShipHaul;
        private decimal[] LiveWeight;
        private string[] fishSpecies;
        private decimal[] QuotaFilled;
        private decimal TotalHaul;

        public Fleet()
        {
            Name = "N/A";
            LicenceNumber = "N/A";
            MaximumLoad = 0m;
            ShipHaul = 0m;
            LiveWeight = new decimal[] { 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m};
            fishSpecies = new string[] { "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A"};
            QuotaFilled = new decimal[] { 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m};
        }

        public Fleet(string ShipName, string ShipLicence, decimal MaximumCapacity, decimal SelectedShipHaul, string[] caughtSpecies, decimal[] QuotaCaught, decimal[] SelectedShipLiveWeight)
        {
            Name = ShipName;
            LicenceNumber = ShipLicence;
            MaximumLoad = MaximumCapacity;
            ShipHaul = SelectedShipHaul;
            fishSpecies = caughtSpecies;
            QuotaFilled = QuotaCaught;
            LiveWeight = SelectedShipLiveWeight;
        }

        public string GetName
        {
            get
            {
                return Name;
            }
            set
            {
                Name = value;
            }
        }

        public string GetLicence
        {
            get
            {
                return LicenceNumber;
            }
            set
            {
                LicenceNumber = value;
            }
        }

        public decimal GetMaximumLoad
        {
            get
            {
                return MaximumLoad;
            }
            set
            {
                MaximumLoad = value;
            }
        }

        public decimal GetShipHaul
        {
            get
            {
                return ShipHaul;
            }
            set
            {
                ShipHaul = value;
            }
        }

        public decimal[] GetLiveWeight
        {
            get
            {
                return LiveWeight;
            }
            set
            {
                LiveWeight = value;
            }
        }

        public string[] GetFishSpecies
        {
            get
            {
                return fishSpecies;
            }
            set
            {
                fishSpecies = value;
            }
        }

        public decimal[] GetFilledQuota
        {
            get
            {
                return QuotaFilled;
            }
            set
            {
                QuotaFilled = value;
            }
        }
    }
}